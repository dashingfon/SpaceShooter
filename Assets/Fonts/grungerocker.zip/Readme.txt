	*****************************************************************
	You've downloaded a Samuel Park font
	 -http://www.peppesbodega.nu/type
	 -spark@hem.utfors.se
	*****************************************************************
		
	Feel free to use them in personal, non-money-making and fun stuff. 
	If you want to include them in a font-cd or such, be sure to 
	have my permission. Don't remake or rename the fonts. 
	If you want to post them on your page, that's cool as long as you 
	post the original zip file with all the files in it.
	
	All fonts �Samuel Park 1998-2000
	*****************************************************************